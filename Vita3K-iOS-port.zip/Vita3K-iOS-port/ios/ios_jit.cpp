// JIT helpers for iOS 15+.
//  - Debugger-enabled JIT (StikDebug / AltJIT / SideJITServer / Xcode): kernel sets CS_DEBUGGED -> plain RWX anonymous mmap works.
//  - Entitled builds (TrollStore: dynamic-codesigning/get-task-allow...): MAP_JIT works.
//  - TrollStore self-enable: a forked child attaches to the parent with ptrace and detaches, which leaves CS_DEBUGGED set.
#include "ios_jit.h"
#include <cstdint>
#include <dlfcn.h>
#include <sys/mman.h>
#include <sys/wait.h>
#include <unistd.h>

extern "C" int csops(pid_t pid, unsigned int ops, void *useraddr, size_t usersize);
extern "C" int ptrace(int request, pid_t pid, void *addr, int data);

static constexpr unsigned kCsOpsStatus = 0;
static constexpr unsigned kCsDebugged = 0x10000000;
static constexpr int kPtAttachExc = 14;
static constexpr int kPtDetach = 11;

static bool cs_debugged() {
    uint32_t flags = 0;
    return csops(getpid(), kCsOpsStatus, &flags, sizeof(flags)) == 0 && (flags & kCsDebugged);
}

static bool try_map(int extra_flags) {
    void *p = mmap(nullptr, 0x4000, PROT_READ | PROT_WRITE | PROT_EXEC, MAP_PRIVATE | MAP_ANON | extra_flags, -1, 0);
    if (p == MAP_FAILED)
        return false;
    munmap(p, 0x4000);
    return true;
}

extern "C" int ios_jit_use_map_jit(void) {
    static int cached = -1;
    if (cached < 0)
        cached = try_map(MAP_JIT) ? 1 : 0;
    return cached;
}

bool ios_jit_available() {
    if (cs_debugged())
        return try_map(0) || try_map(MAP_JIT);
    return try_map(MAP_JIT);
}

bool ios_jit_try_enable() {
    if (ios_jit_available())
        return true;
    // fork() is marked unavailable in the iOS SDK headers; resolve it dynamically (only permitted for TrollStore-style entitlements)
    using fork_fn = pid_t (*)();
    auto fork_ptr = reinterpret_cast<fork_fn>(dlsym(RTLD_DEFAULT, "fork"));
    if (!fork_ptr)
        return false;
    const pid_t parent = getpid();
    const pid_t child = fork_ptr();
    if (child == 0) {
        if (ptrace(kPtAttachExc, parent, nullptr, 0) == 0) {
            usleep(20000);
            ptrace(kPtDetach, parent, nullptr, 0);
        }
        _exit(0);
    }
    if (child < 0)
        return false;
    int status = 0;
    waitpid(child, &status, 0);
    usleep(20000);
    return ios_jit_available();
}
