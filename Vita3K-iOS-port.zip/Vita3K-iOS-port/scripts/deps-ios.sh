#!/bin/bash
# usage: deps-ios.sh <source_dir>   (source_dir is only inspected to pick the FFmpeg version)
# Builds static iOS arm64 dependencies into $IOS_DEPS: OpenSSL, Boost(filesystem), curl, FFmpeg + MoltenVK.framework
set -ex
SRC_DIR="${1:-}"
: "${IOS_DEPS:=$PWD/ios-deps}"; export IOS_DEPS
MIN=16.4  # std::format/to_chars(double) needs iOS >= 16.3; ignore workflow IOS_MIN
mkdir -p "$IOS_DEPS" deps-build && cd deps-build
SDK=$(xcrun --sdk iphoneos --show-sdk-path)
CCBIN=$(xcrun --sdk iphoneos --find clang)
CXXBIN=$(xcrun --sdk iphoneos --find clang++)
ARCHF="-arch arm64 -miphoneos-version-min=$MIN -isysroot $SDK"
NCPU=$(sysctl -n hw.ncpu)

dl() { # url out  (3 retries)
  for i in 1 2 3; do curl -fL --retry 3 -o "$2" "$1" && return 0; sleep 3; done; return 1
}

# ---- MoltenVK (dynamic framework bundled into the app) ----
if [ ! -d "$IOS_DEPS/Frameworks/MoltenVK.framework" ]; then
  gh release download --repo KhronosGroup/MoltenVK -p 'MoltenVK-ios.tar' --clobber 2>/dev/null || \
    dl https://github.com/KhronosGroup/MoltenVK/releases/download/v1.2.11-artifacts/MoltenVK-ios.tar MoltenVK-ios.tar || \
    dl https://github.com/KhronosGroup/MoltenVK/releases/latest/download/MoltenVK-ios.tar MoltenVK-ios.tar
  mkdir -p mvk && tar -xf MoltenVK-ios.tar -C mvk
  FW=$(find mvk -path '*dynamic*' -path '*ios-arm64/MoltenVK.framework' -type d | grep -vi simulator | head -1)
  [ -n "$FW" ] || FW=$(find mvk -name MoltenVK.framework -type d | grep -vi simulator | grep arm64 | head -1)
  [ -n "$FW" ] || { echo "MoltenVK.framework not found in tar"; find mvk | head -60; exit 1; }
  mkdir -p "$IOS_DEPS/Frameworks" && cp -R "$FW" "$IOS_DEPS/Frameworks/"
fi

# ---- OpenSSL ----
if [ ! -f "$IOS_DEPS/lib/libcrypto.a" ]; then
  dl https://github.com/openssl/openssl/releases/download/openssl-3.3.2/openssl-3.3.2.tar.gz openssl.tgz
  tar -xzf openssl.tgz && pushd openssl-3.3.2
  ./Configure ios64-xcrun no-shared no-tests no-apps no-docs -miphoneos-version-min=$MIN --prefix="$IOS_DEPS"
  make -j"$NCPU" build_libs
  make install_dev
  popd
fi

# ---- Boost: b2 first, manual compile of filesystem as fallback ----
if [ ! -f "$IOS_DEPS/lib/libboost_filesystem.a" ]; then
  dl https://archives.boost.io/release/1.85.0/source/boost_1_85_0.tar.gz boost.tgz
  tar -xzf boost.tgz && pushd boost_1_85_0
  ok=0
  if ./bootstrap.sh --with-libraries=filesystem,atomic,system; then
    cat > user-config.jam <<JAM
using darwin : ios : $CXXBIN : <compileflags>"$ARCHF -fvisibility=hidden -fvisibility-inlines-hidden" <linkflags>"-arch arm64 -isysroot $SDK" <striper> ;
JAM
    ./b2 --user-config=user-config.jam toolset=darwin-ios target-os=iphone architecture=arm abi=aapcs address-model=64 \
         binary-format=mach-o link=static runtime-link=static variant=release threading=multi cxxstd=20 \
         --prefix="$IOS_DEPS" --with-filesystem --with-atomic --with-system -j"$NCPU" install && ok=1
  fi
  if [ $ok != 1 ] || [ ! -f "$IOS_DEPS/lib/libboost_filesystem.a" ]; then
    echo "b2 failed -> manual build of boost_filesystem"
    mkdir -p "$IOS_DEPS/include" "$IOS_DEPS/lib" obj && rm -f obj/*.o
    cp -R boost "$IOS_DEPS/include/"
    for f in libs/filesystem/src/*.cpp libs/atomic/src/lock_pool.cpp; do
      [ -f "$f" ] || continue
      case "$f" in *windows_file_codecvt*) continue;; esac
      "$CXXBIN" $ARCHF -std=c++20 -O2 -fPIC -I. -DBOOST_ALL_NO_LIB -DBOOST_FILESYSTEM_STATIC_LINK=1 -DBOOST_ATOMIC_STATIC_LINK=1 \
        -DBOOST_FILESYSTEM_SOURCE -DBOOST_ATOMIC_SOURCE -Ilibs/filesystem/src -c "$f" -o "obj/$(basename "$f").o" || true
    done
    ar rcs "$IOS_DEPS/lib/libboost_filesystem.a" obj/*.o
    cp "$IOS_DEPS/lib/libboost_filesystem.a" "$IOS_DEPS/lib/libboost_atomic.a"
  fi
  popd
fi

# ---- curl (CMake build: the autotools cross-compile checks fail on iOS) ----
if [ ! -f "$IOS_DEPS/lib/libcurl.a" ]; then
  dl https://curl.se/download/curl-8.8.0.tar.gz curl.tgz
  tar -xzf curl.tgz
  cmake -S curl-8.8.0 -B curl-build -G Ninja \
    -DCMAKE_SYSTEM_NAME=iOS -DCMAKE_OSX_SYSROOT=iphoneos -DCMAKE_OSX_ARCHITECTURES=arm64 \
    -DCMAKE_OSX_DEPLOYMENT_TARGET=$MIN -DCMAKE_BUILD_TYPE=Release -DCMAKE_POLICY_VERSION_MINIMUM=3.5 \
    -DCMAKE_INSTALL_PREFIX="$IOS_DEPS" -DCMAKE_PREFIX_PATH="$IOS_DEPS" -DCMAKE_FIND_ROOT_PATH="$IOS_DEPS" \
    -DCMAKE_FIND_ROOT_PATH_MODE_LIBRARY=BOTH -DCMAKE_FIND_ROOT_PATH_MODE_INCLUDE=BOTH -DCMAKE_FIND_ROOT_PATH_MODE_PACKAGE=BOTH \
    -DCMAKE_TRY_COMPILE_TARGET_TYPE=STATIC_LIBRARY \
    -DOPENSSL_ROOT_DIR="$IOS_DEPS" -DOPENSSL_USE_STATIC_LIBS=ON \
    -DBUILD_SHARED_LIBS=OFF -DBUILD_STATIC_LIBS=ON -DBUILD_CURL_EXE=OFF -DBUILD_TESTING=OFF \
    -DCURL_USE_OPENSSL=ON -DCURL_USE_LIBPSL=OFF -DUSE_NGHTTP2=OFF -DCURL_BROTLI=OFF -DCURL_ZSTD=OFF \
    -DCURL_USE_LIBSSH2=OFF -DUSE_LIBIDN2=OFF -DCURL_DISABLE_LDAP=ON -DCURL_DISABLE_LDAPS=ON
  cmake --build curl-build -j"$NCPU"
  cmake --install curl-build
fi

# ---- FFmpeg: version taken from ffmpeg-core when detectable ----
FF_VER="${FFMPEG_VERSION:-}"
if [ -z "$FF_VER" ] && [ -n "$SRC_DIR" ] && [ -d "$SRC_DIR/external/ffmpeg" ]; then
  FF_VER=$(grep -rhoiE "ffmpeg[-_ /]*(n|version[ =:]*)?[67]\.[0-9](\.[0-9]+)?" "$SRC_DIR/external/ffmpeg" 2>/dev/null | grep -oE "[67]\.[0-9](\.[0-9]+)?" | sort -V | tail -1 || true)
fi
case "$FF_VER" in 6.0|6.0.*|6.1|6.1.*|7.0|7.0.*|7.1|7.1.*) ;; *) FF_VER=6.1.1;; esac
case "$FF_VER" in *.*.*) ;; *) FF_VER="$FF_VER";; esac
echo "FFmpeg version: $FF_VER"
if [ ! -f "$IOS_DEPS/lib/libavcodec.a" ]; then
  dl "https://ffmpeg.org/releases/ffmpeg-$FF_VER.tar.xz" ffmpeg.txz || dl "https://ffmpeg.org/releases/ffmpeg-6.1.1.tar.xz" ffmpeg.txz
  mkdir -p ffsrc && tar -xJf ffmpeg.txz -C ffsrc --strip-components=1 && pushd ffsrc
  CONF=(--prefix="$IOS_DEPS" --enable-cross-compile --target-os=darwin --arch=arm64
    --cc="$CCBIN $ARCHF" --as="$CCBIN $ARCHF" --extra-ldflags="-arch arm64 -isysroot $SDK"
    --enable-static --disable-shared --enable-pic --enable-neon
    --disable-programs --disable-doc --disable-debug --disable-network --disable-avdevice
    --disable-encoders --disable-muxers --disable-iconv --disable-securetransport
    --disable-audiotoolbox --disable-videotoolbox --disable-xlib --disable-sdl2)
  ./configure "${CONF[@]}" || ./configure "${CONF[@]}" --disable-asm
  make -j"$NCPU"
  make install
  # Vita3K's AAC decoder includes an FFmpeg-internal header -> install it too
  cp libavcodec/codec_internal.h "$IOS_DEPS/include/libavcodec/"
  cp config.h "$IOS_DEPS/include/config.h"
  popd
fi
ls "$IOS_DEPS" "$IOS_DEPS/lib" | head -60

# ---- verify everything we need exists (fail loudly, not later at link time) ----
missing=0
for l in libcrypto.a libssl.a libboost_filesystem.a libcurl.a libavcodec.a libavformat.a libavutil.a libswresample.a libswscale.a; do
  [ -f "$IOS_DEPS/lib/$l" ] || { echo "MISSING DEPENDENCY: $l"; missing=1; }
done
[ -d "$IOS_DEPS/Frameworks/MoltenVK.framework" ] || { echo "MISSING DEPENDENCY: MoltenVK.framework"; missing=1; }
[ -f "$IOS_DEPS/include/libavcodec/codec_internal.h" ] || { echo "MISSING DEPENDENCY: codec_internal.h"; missing=1; }
exit $missing
