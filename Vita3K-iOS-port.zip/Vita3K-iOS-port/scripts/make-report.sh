#!/bin/bash
# Builds REPORT.md from logs/*.log : job status, error lines, and the tail of every log.
OUT="${1:-REPORT.md}"
{
echo "# Vita3K iOS build report"
echo "- run: ${GITHUB_SERVER_URL:-}/${GITHUB_REPOSITORY:-}/actions/runs/${GITHUB_RUN_ID:-}"
echo "- result: **${JOB_STATUS:-unknown}**"
echo "- date: $(date -u '+%Y-%m-%d %H:%M UTC')"
echo
echo "## Error lines"
echo '```'
grep -nHiE "error:|\berror\b.*(cmake|ninja)|FAILED:|fatal error|undefined symbol|ld: |No such file|not found|CMake Error|Traceback|PATCH FAILED|exit code" logs/*.log 2>/dev/null | grep -viE "Werror|-Wno-error|error_code|error\.h|errors\.o|CMakeError\.log|NO_ERROR|ErrorCategory" | head -80
echo '```'
for f in logs/*.log; do
  [ -f "$f" ] || continue
  echo; echo "## $(basename "$f") (last 60 lines)"; echo '```'; tail -n 60 "$f" | cut -c1-300; echo '```'
done
} > "$OUT"
head -c 900000 "$OUT" > "$OUT.tmp" && mv "$OUT.tmp" "$OUT"
