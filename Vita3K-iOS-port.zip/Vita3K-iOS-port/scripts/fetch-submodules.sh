#!/bin/bash
# GitHub's "Download ZIP" does not contain submodules. Re-create them from .gitmodules.
# usage: fetch-submodules.sh <source_dir> [owner/repo that pins the submodule commits]
set -u
SRC="$1"; PIN_REPO="${2:-nckstwrt/Vita3K-Plus}"
cd "$SRC"

# path -> pinned sha. Gitlinks are lost in the zip, so read them from the project's own GitHub tree (primary),
# and from upstream Vita3K only for paths the primary does not know.
: > /tmp/pins.txt
for R in "$PIN_REPO" "Vita3K/Vita3K"; do
  gh api "repos/${R}/git/trees/HEAD?recursive=1" \
    --jq '.tree[] | select(.type=="commit") | "\(.path) \(.sha)"' 2>/dev/null > /tmp/pins_$$.txt || : > /tmp/pins_$$.txt
  echo "pins from ${R}: $(wc -l < /tmp/pins_$$.txt)"
  while read -r pth sha; do grep -q "^${pth} " /tmp/pins.txt || echo "$pth $sha" >> /tmp/pins.txt; done < /tmp/pins_$$.txt
done
echo "pinned submodules total: $(wc -l < /tmp/pins.txt)"

python3 - <<'PY' > /tmp/mods.txt
import re
t = open('.gitmodules').read()
for blk in re.split(r'\[submodule[^\]]*\]', t)[1:]:
    p = re.search(r'path\s*=\s*(\S+)', blk); u = re.search(r'url\s*=\s*(\S+)', blk)
    b = re.search(r'branch\s*=\s*(\S+)', blk)
    if p and u: print(p.group(1), u.group(1), b.group(1) if b else '-')
PY

git init -q . 2>/dev/null || true
fail=0
while read -r path url branch; do
  [ -n "$(ls -A "$path" 2>/dev/null)" ] && { echo "skip (present): $path"; continue; }
  sha=$(grep -E "^${path} " /tmp/pins.txt | awk '{print $2}')
  echo "== $path  ($url)  pin=${sha:-none}"
  rm -rf "$path"; mkdir -p "$path"
  (
    cd "$path" && git init -q && git remote add origin "$url"
    ok=0
    if [ -n "$sha" ] && git fetch -q --depth 1 origin "$sha"; then ok=1
    elif [ "$branch" != "-" ] && git fetch -q --depth 1 origin "$branch"; then ok=1
    elif git fetch -q --depth 1 origin HEAD; then ok=1; fi
    [ $ok = 1 ] || exit 1
    git checkout -q FETCH_HEAD
    git submodule update --init --recursive --depth 1 -q 2>/dev/null || git submodule update --init --recursive -q
  ) || { echo "FAILED: $path"; fail=1; }
done < /tmp/mods.txt
exit $fail
